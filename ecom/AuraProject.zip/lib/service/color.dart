import 'package:flutter/material.dart';


   const Color button =  Color.fromARGB(255, 156, 44, 81);
   const Color nav = Color.fromARGB(255, 156, 44, 81);
   const Color backgroundcolor = Color.fromARGB(255, 255, 129, 171);
   const Color catcolor = Color.fromARGB(255, 247, 87, 140);
 // static const Color secondaryColor = Colors.green;